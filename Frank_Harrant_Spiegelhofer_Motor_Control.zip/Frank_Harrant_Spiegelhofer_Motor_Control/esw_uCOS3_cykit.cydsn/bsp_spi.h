/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <cpu.h>

#include <SPIM_1.h>

CPU_VOID spi_init(CPU_VOID);

CPU_VOID spi_start(CPU_VOID);

CPU_INT16U spi_read(CPU_VOID);

CPU_VOID int2str(CPU_INT16U value, CPU_CHAR *buffer);

CPU_INT16U MCP3204_Read(CPU_INT08U channel);

/* [] END OF FILE */
