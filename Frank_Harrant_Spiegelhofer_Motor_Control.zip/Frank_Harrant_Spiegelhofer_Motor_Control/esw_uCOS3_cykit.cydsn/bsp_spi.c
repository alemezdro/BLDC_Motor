/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <bsp_spi.h>
#include <stdio.h>
#include <UART_1.h>

CPU_VOID spi_init(CPU_VOID){

    SPIM_1_Init();
    
}

CPU_VOID spi_start(CPU_VOID){

    SPIM_1_Start();

}

CPU_INT16U spi_read(CPU_VOID){

    CPU_INT16U spi_value;
    spi_value = SPIM_1_ReadRxData();
    return spi_value;

}

CPU_VOID int2str(CPU_INT16U value, CPU_CHAR *buffer){

    CPU_INT16U count1 = 0;
    
    CPU_CHAR temp[6];
    
    do {
        temp[count1++] = (value % 10) + '0';
        value /= 10;
    } while (value > 0);
    
    CPU_INT16U count2 = 0;
    
    while (count1 > 0) buffer[count2++] = temp[--count1];
    buffer[count2] = '\0';
    
}

CPU_INT16U MCP3204_Read(CPU_INT08U channel){
    CPU_INT08U tx[3];
    CPU_INT08U rx[3];
    CPU_INT16U result;
    
    tx[0] = 0b00000110 | ((channel >> 2) & 0x01);
    tx[1] = (channel & 0x03) << 6;
    tx[2] = 0x00;

    SPIM_1_ClearRxBuffer();
    SPIM_1_PutArray(tx, 3);
    while(!(SPIM_1_ReadTxStatus() & SPIM_1_STS_SPI_DONE));

    rx[0] = SPIM_1_ReadRxData();
    rx[1] = SPIM_1_ReadRxData();
    rx[2] = SPIM_1_ReadRxData();

    result = ((rx[1] & 0x0F) << 8) | rx[2];
    return result;
    
}
/* [] END OF FILE */
